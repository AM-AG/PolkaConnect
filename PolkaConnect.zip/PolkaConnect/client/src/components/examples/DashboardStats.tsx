import { DashboardStats } from '../DashboardStats'

export default function DashboardStatsExample() {
  return <DashboardStats />
}
