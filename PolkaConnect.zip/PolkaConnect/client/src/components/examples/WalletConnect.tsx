import { WalletConnect } from '../WalletConnect'

export default function WalletConnectExample() {
  return <WalletConnect />
}
