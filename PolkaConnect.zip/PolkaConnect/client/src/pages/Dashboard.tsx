import { MultiChainStats } from "@/components/MultiChainStats";
import { CommunityStats } from "@/components/CommunityStats";
import { BalanceCard } from "@/components/BalanceCard";
import { ProposalCard } from "@/components/ProposalCard";
import { VoteDialog } from "@/components/VoteDialog";
import { useToast } from "@/hooks/use-toast";
import { useMultiWallet } from "@/hooks/useMultiWallet";
import { useMultiChainBalances } from "@/hooks/useMultiChainBalances";
import { useGovernance } from "@/hooks/useGovernance";
import { useXcmData } from "@/hooks/useXcmData";
import { useWallet } from "@/contexts/WalletContext";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Wallet } from "lucide-react";
import { useState } from "react";

export default function Dashboard() {
  const { toast } = useToast();
  const { walletState, isAnyConnected } = useMultiWallet();
  const { activePolkadotAccount } = useWallet();
  const { data: balances, isLoading: balancesLoading, refetch: refetchBalances } = useMultiChainBalances(walletState);
  const { data: proposals, isLoading: proposalsLoading } = useGovernance();
  const { data: xcmChannels } = useXcmData();
  const [voteDialogOpen, setVoteDialogOpen] = useState(false);
  const [selectedProposal, setSelectedProposal] = useState<{id: number; title: string} | null>(null);

  const handleVote = (proposalId: number, proposalTitle: string, voteDirection?: "aye" | "nay") => {
    if (!activePolkadotAccount) {
      toast({
        variant: "destructive",
        title: "Wallet Not Connected",
        description: "Please connect your Polkadot wallet to vote",
      });
      return;
    }
    setSelectedProposal({ id: proposalId, title: proposalTitle });
    setVoteDialogOpen(true);
  };

  const handleRefresh = (chainName: string) => {
    console.log(`Refreshing ${chainName} balance`);
    refetchBalances();
    toast({
      title: "Balance Updated",
      description: `${chainName} balance has been refreshed`,
    });
  };

  if (!isAnyConnected) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Alert className="max-w-md">
          <Wallet className="h-4 w-4" />
          <AlertDescription>
            Please connect your wallet (Polkadot or MetaMask) to view your dashboard and balances.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const formatLastUpdated = (isoString: string) => {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins} min${diffMins > 1 ? 's' : ''} ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold mb-2">Multi-Chain Dashboard</h1>
        <p className="text-muted-foreground">
          Monitor your portfolio across Polkadot and Ethereum ecosystems
        </p>
      </div>

      <MultiChainStats />

      <div>
        <h2 className="text-2xl font-semibold mb-4">Community Overview</h2>
        <CommunityStats />
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Chain Balances</h2>
        {balancesLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-40 bg-card rounded-lg animate-pulse" />
            ))}
          </div>
        ) : balances && balances.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {balances.map((balance) => (
              <BalanceCard
                key={balance.chainId}
                chainName={balance.chainName}
                chainIcon={balance.chainId === 'polkadot' ? '●' : balance.chainId === 'ethereum' ? 'Ξ' : balance.chainId === 'astar' ? '★' : '◐'}
                balance={`${balance.balance} ${balance.symbol}`}
                usdValue={balance.usdValue}
                lastUpdated={formatLastUpdated(balance.lastUpdated)}
                status={balance.status}
                onRefresh={() => handleRefresh(balance.chainName)}
                symbol={balance.symbol}
              />
            ))}
          </div>
        ) : (
          <Alert>
            <AlertDescription>
              No balances found. Make sure your wallet has assets on supported chains.
            </AlertDescription>
          </Alert>
        )}
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Recent Proposals</h2>
        {proposalsLoading ? (
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="h-48 bg-card rounded-lg animate-pulse" />
            ))}
          </div>
        ) : proposals && proposals.length > 0 ? (
          <div className="space-y-4">
            {proposals.slice(0, 5).map((proposal) => (
              <ProposalCard
                key={proposal.id}
                {...proposal}
                onVote={(voteDirection) => handleVote(proposal.id, proposal.title, voteDirection)}
              />
            ))}
          </div>
        ) : (
          <Alert>
            <AlertDescription>
              No active proposals at the moment. Check back later for governance updates.
            </AlertDescription>
          </Alert>
        )}
      </div>

      {selectedProposal && (
        <VoteDialog
          open={voteDialogOpen}
          onOpenChange={setVoteDialogOpen}
          proposalId={selectedProposal.id}
          proposalTitle={selectedProposal.title}
        />
      )}
    </div>
  );
}
